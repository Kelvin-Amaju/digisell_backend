const TextGradient = () => {
  return (
    <span className='bg-gradient-to-t from-[#c7d2fe] to-[#8678f9] bg-clip-text text-xl text-transparent'>
      Sample Text
    </span>
  );
};

export default TextGradient;
